#pragma once
#include <string>
#include <vector>
class Course
{
private:
	Course(std::string id, std::string title, std::vector<std::string> prerequisites);
public:
	~Course();
	std::string id;//"CS200"
	std::string title;//"Discrete Mathematics"
	std::vector<std::string> prerequisitesStrings;//"CS200, MAT200"
	std::vector<Course*> prerequisites;// {CS200, MAT200}
	std::vector<Course*> fullPrerequisites;// {CS100, CS200, MAT100, MAT200}

	
	static Course* StringToCourse(std::string);
	std::vector<std::string> GetDescription();

};


