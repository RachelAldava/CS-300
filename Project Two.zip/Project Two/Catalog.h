#pragma once
#include <string>
#include <vector>
#include "Course.h"
class Catalog {

public:
	Catalog();
	void ImportCSV(std::string path = "");
	void PrintCourse(std::string searchedId);
	void PrintCatalog();

	

private:

	std::vector<Course *> alphabeticalVector = {};// A vector of pointers which is kept alphabetized
	std::vector<std::vector<Course *>> hashTable = {};// The storage location of the courses
	int tableSize;// keeps track of the current table size

	void Insert(Course* course);
	void Alphabetize();
	void ResizeHashTable(int tableSize);
	void RefreshPrerequisites();
	void RefreshFullPrerequisites();
	void RefreshFullPrerequisites(std::vector<Course*>* unsorted, Course* curr);
	Course* GetCourseByID(std::string searchedId);
	unsigned int GetHash(std::string key);

};

