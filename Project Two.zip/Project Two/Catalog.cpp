#include "Catalog.h"
#include "Course.h"
#include <fstream>
#include <iostream>
#include <algorithm>


// Creates an empty Catalog
Catalog::Catalog() {
	this->tableSize = 0;
}

// Adds the contents of a CSV file onto an existing Catalog object
void Catalog::ImportCSV(std::string path) {

	// Open file, count the lines we are adding, and prepare hashtable
	
	std::ifstream stream(path);

	int numCourses = 0;// The number of lines in the CSV file
	for (std::string line; std::getline(stream, line); )numCourses++;
	numCourses = int(numCourses * 1.3); // Add some wiggle room
	this->ResizeHashTable(this->tableSize + numCourses);

	stream.clear();
	stream.seekg(0, std::ios::beg);// reset file to be read again
	
	// Import courses
	for (std::string line; std::getline(stream, line); ) {
		Course* course = Course::StringToCourse(line);
		if (course) this->Insert(course);
	}

	// Refresh the prerequisites
	this->RefreshPrerequisites();

	// Refresh the full prerequisites
	this->RefreshFullPrerequisites();

	// Retain the alphabetization
	this->Alphabetize();
}

// Handles course insertion
void Catalog::Insert(Course* course) {

	// insert pointer into the hashtable
	this->hashTable[this->GetHash(course->id)].push_back(course);

	// insert pointer into the alphabetical vector
	this->alphabeticalVector.push_back(course);

}

// This will alphabetize the catalog's alphabeticalVector and all of its courses' prerequisites and fullPrerequisites
void Catalog::Alphabetize() {

	// alphabetize alphabeticalVector
	std::sort(this->alphabeticalVector.begin(), this->alphabeticalVector.end(),
		[](Course* const& a, Course* const& b) {
			return a->id < b->id;
		});

	for (int hash = 0; hash < this->hashTable.size(); hash ++) {
		for (int i = 0; i < this->hashTable[hash].size(); i++) {
			// Alphabetize prerequisites
			std::sort(this->hashTable[hash][i]->prerequisites.begin(), this->hashTable[hash][i]->prerequisites.end(),
				[](Course* const& a, Course* const& b) {
					return a->id < b->id;
				});

			// Alphabetize full prerequisites
			std::sort(this->hashTable[hash][i]->fullPrerequisites.begin(), this->hashTable[hash][i]->fullPrerequisites.end(),
				[](Course* const& a, Course* const& b) {
					return a->id < b->id;
				});

		}
	}
}

// This method refactors the hash table based on the current courseList vector
void Catalog::ResizeHashTable(int tableSize) {
	
	//resize
	this->tableSize = tableSize;

	//repopulate
	std::vector<std::vector<Course *>> newHashTable = {};
	for (int i = 0; i < this->tableSize; i++) {
		newHashTable.push_back({});
	}

	for (auto hash : this->hashTable) {
		for (auto course : hash) {
			newHashTable[this->GetHash(course->id)].push_back(course);
		}
	}

	//replace
	this->hashTable = newHashTable;
}

// Creates a hash using djb2 algorithm with this.tableSize
unsigned int Catalog::GetHash(std::string key) {
	unsigned int hash = 5381;

	for (char c : key)
		hash += (hash * 33) + int(c);

	hash = hash % this->tableSize;

	return hash;
}

// Returns a course pointer which matches the provided id string, failure to locate returns a null pointer
Course* Catalog::GetCourseByID(std::string searchedId) {
	unsigned int index = this->GetHash(searchedId);
	for (int i = 0; i < this->hashTable[index].size(); i++) {
		if (this->hashTable[index][i]->id.compare(searchedId) == 0) {
			return this->hashTable[index][i];
		}
	}
	return nullptr;
}

// Iterates through courseList and populates each course's prerequisites, if they exist.
void Catalog::RefreshPrerequisites() {

	// for each hash in the hash table
	for (int hash = 0; hash < this->hashTable.size(); hash++){

		// for each course in the hash
		for (int i = 0; i < this->hashTable[hash].size(); i++) {

			// for each string in the course's prerequisitesStrings
			for (auto string: this->hashTable[hash][i]->prerequisitesStrings) {
				
				// get a course from the string
				Course* prereq = this->GetCourseByID(string);

				// and add it to the prerequisites
				if (prereq->id.size() > 0) { 
					hashTable[hash][i]->prerequisites.push_back(prereq);
				}
			
				else std::cout << "ERROR: Attempted to add \"" << string << "\" to " << hashTable[hash][i]->id << " but could not find any course with that ID." << std::endl;
			}
		}
	}
}

// driver method for a recursive method of the same name; refreshes the full prerequisites for all courses in the hashtable
void Catalog::RefreshFullPrerequisites() {
	
	// Keep track of the courses we already sorted
	std::vector<Course*> sorted;

	// for every course, call the recursive function
	for (int hash = 0; hash < this->hashTable.size(); hash++) {
		for (int i = 0; i < this->hashTable[hash].size(); i++) {
			this->RefreshFullPrerequisites(&sorted, this->hashTable[hash][i]);
		}
	}
}

void Catalog::RefreshFullPrerequisites(std::vector<Course*>* sorted, Course* curr) {

	// If the course is already sorted
	for (auto pointer : *sorted) {
		if (pointer == curr) {
			return;
		}
	}
	
	// At minimum, a course will have its own prerequisites in its full prerequisites
	curr->fullPrerequisites = curr->prerequisites;

	//Base case
	if (curr->prerequisites.size() == 0) {
		sorted->push_back(curr);
		return;
	}

	// For course in prerequisites
	for (int i = 0; i < curr->prerequisites.size(); i++) {
		// refresh each prerequisite's full-prerequisites
		this->RefreshFullPrerequisites(sorted, curr->prerequisites[i]);
		sorted->push_back(curr->prerequisites[i]);
	}

	// Flatten the full prerequisites of child courses into parent full prerequisites
	for (auto prereq : curr->prerequisites){
		for (auto fullprereq : prereq->fullPrerequisites) {
			bool needsAdded = true;
			for (auto existingPrereq : curr->fullPrerequisites) {
				if (existingPrereq == fullprereq) needsAdded = false;
			}

			if (needsAdded) curr->fullPrerequisites.push_back(fullprereq);
		}
	}
}


// Attempts to find and print course information based off a provided string
void Catalog::PrintCourse(std::string searchedId) {

	// get the course
	Course* course = this->GetCourseByID(searchedId);

	// If there is a course
	if (course) {
		std::cout << std::endl << std::endl;
		std::cout << "getting description..." << std::endl;
		std::vector<std::string> description = course->GetDescription();

		for (std::string line : description) std::cout << line << std::endl;
	}

	// Else there is no course
	else std::cout << "No such course found. Id match must be exact (case sensitive)" << std::endl << std::endl << std::endl;
}

// Iterates through the alphabetial list, printing off information for each course.
void Catalog::PrintCatalog() {
	for (auto pointer : this->alphabeticalVector) {
		std::vector<std::string> description = pointer->GetDescription();

		for (std::string line : description) std::cout << line << std::endl;
	}
}
