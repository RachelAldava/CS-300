#include <iostream>
#include "Course.h"
#include "Catalog.h"

#include <fstream>
#include <string>
#include <vector>

int main(int argc, char* argv[]) {
    std::string path;

    if (argc > 1) {
        std::string path(argv[1]);
        if (path.substr(path.length() - 4) != ".csv" && path.substr(path.length() - 4) != ".txt") {
            std::cout << "I'm sorry, I didn't understand the parameters the .exe file was called under" << std::endl;
            std::cout << "I can read .txt files and .csv files" << std::endl;
            return -1;
        }

    }
    else path = "ABCU_Advising_Program_Input.csv";

    // create empty catalog
    Catalog catalog = Catalog();

    // define menu
    std::vector<std::string> menu = {
        // Load the file data into the data structure.
        "\na. Load Data Structure",

        // This will print an alphanumeric list of all the courses in the Computer Science department.
        "b. Print Course List",

        // This will print the course title and the prerequisites for any individual course.
        "c. Print Course",

        // This will exit you out of the program.
        "d. Exit",

        //
        "\nPlease enter a letter:"
    };

    // handle user input
    std::string id;
    std::string command = "";
    char c = '?';
    while (c != 'd' && c != 'D') {

        for (auto line : menu) std::cout << line << std::endl;

        std::cin >> command;
        if (command.size() == 1) c = command[0];
        else c = '?';

        switch (c){

        // if "Load Data Structure"
        case 'a':
        case 'A':

            std::cout << "Loading Data Structure...";

            catalog.ImportCSV(path);
            std::cout << "   done." << std::endl;
            break;
        
        // if "Print Course List"
        case 'b':
        case 'B':

            catalog.PrintCatalog();
            break;
        
        // if "Print Course"
        case 'c':
        case 'C':

            std::cout << std::endl << std::endl << "Sure thing Hoss, just need you to input a course id." << std::endl;
            std::cout << "For example, you could type \"CSCI400\"." << std::endl << std::endl;
            std::cout << "Please enter a course id:" << std::endl;

            std::cin >> id;

            catalog.PrintCourse(id);
            break;

        case 'd':
        case 'D':

            std::cout << "Exiting" << std::endl;
            break;

        default:
            std::cout << "I didn't quite get that. Please try again.\n" << std::endl;
            break;
        }

    }

    std::cout << "Y'all have a good day now" << std::endl;

    return 0;
}