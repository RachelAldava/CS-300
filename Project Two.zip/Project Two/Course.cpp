#include "Course.h"
#include <string>
#include <vector>
#include <iostream>

// Creates a course object
Course::Course(std::string id, std::string title, std::vector<std::string> prerequisites) {
	this->id = id; // CS300
	this->title = title; // DSA: Analysis and Design
	this->prerequisitesStrings = prerequisites; // {"CS200", "MAT200"}
	this->prerequisites = {};// {CS200, MAT200}
	this->fullPrerequisites = {};// {CS100, CS200, MAT100, MAT200}
	}

Course::~Course() {}

// Converts a string to a Course object. Format: "id,title,prereq 1, ... , prereq n"
Course* Course::StringToCourse(std::string line) {

	std::string cell = "";
	std::string id = "";
	std::string title = "";
	std::vector<std::string> prereq;

	// Look through the line
	for (char c : line) {

		// If it's not a comma, add the character to the cell
		if (c != ',') {
			cell += c;
		}

		// Else it marks the end of the cell. We add it to id if it does not exist yet
		else if (id == "") {
			id = cell;
			cell = "";
			
		}

		// Else we check if a title and populate it if needed
		else if (title == "") {
			title = cell;
			cell = "";
		}

		// Else we add the cell to the prereq vector
		else {
			prereq.push_back(cell);
			cell = "";
		}
	}

	// Finally we add the last cell to the appropriate place
	// Note that a string of "a" would cause a blank id and a title of "a"
	if (title == "") title = cell;
	else prereq.push_back(cell);
	
	// if by now there is no id or no title in the line, then an error must have occured
	if (id == "" || title == "") {
		std::cout << "ERROR READING FILE: line " << line << " encountered an error when attempting to load a course" << std::endl;
		return nullptr;// so if id = "" and title = "a", then a null pointer is returned
	}

	// If everything is all good, we return the new course
	else return new Course(id, title, prereq);
	
}

// Returns a vector of strings which describe a course.
std::vector<std::string> Course::GetDescription() {
	std::vector<std::string> description;

	// add id and title to the description
	description.push_back("ID: " + this->id);
	description.push_back("    Title: " + this->title);

	// add the prerequisites to the description if they exist
	if (this->prerequisites.size() != 0) {
		std::string prereq = "    Prerequisites: ";
		bool sentinel = false;
		for (auto course : this->prerequisites) {
			if (sentinel) prereq += ", ";
			prereq += (course->id);
			sentinel = true;
		}
		description.push_back(prereq);

		// If there is a tree of prerequisites, add the pre-populated full prerequisites
		if (this->fullPrerequisites.size() != this->prerequisites.size()) {
			sentinel = false;
			std::string fullprereq = "    Full Prerequisites: ";
			for (auto course : this->fullPrerequisites) {
				if (sentinel) fullprereq += ", ";
				fullprereq += (course->id);
				sentinel = true;
			}
			description.push_back(fullprereq);
		}
	}

	return description;
}
